<?php 

	Class AboutController extends AppController
	{
            var $uses = false;
            
            function index()
            {
                $this->set('title_for_layout', 'Über diese Seite');
            }	
	}
	
?>