<?php

class IndexCardTrainerController extends AppController
{
    public $helpers = array('Js'); // javascript ajax
    public $components = array('RequestHandler', 'Cookie');

    public function beforeFilter()
    {
        $this->Auth->allow(); // allow nothing
        $this->Auth->deny("index", "getdataset");
        parent::beforeFilter();
    }

    /*
     * Autorisierung
     */
    public function isAuthorized($user)
    {
        return parent::isAuthorizedBase($user);
    }

    function index()
    {
        $this->set('title_for_layout', 'Karteikarten Trainer');
		$this->set('software', 'ict');
        $this->set('submenu', 'ic');

        // if there are passed parameters, pass them to the view, add them to cookies
        if (isset($this->request->query['box']))
            $this->Cookie->write('ict.box', $this->request->query['box'], false);

        if (isset($this->request->query['known']))
            $this->Cookie->write('ict.known', $this->request->query['known'], false);

        // if user comes e.g. from a reminder mail (flag is set in url)
        // and is not logged in, do not show example index cards → refer to login mask
        $lFlagValues = Array('dailyreminder', 'monthlyreminder');
        if (isset($this->request->query['flag']) && in_array($this->request->query['flag'], $lFlagValues) && !$this->Auth->loggedIn())
        {
            return $this->redirect('/User/login?redirect=/IndexCardTrainer');
        }

        $this->loadModel('IndexCardBox');

        // get indexCardBoxes
        if ($this->Auth->loggedIn()) {
            $userId = $this->Auth->user('id');
        } else {
            // get dummy-data from admin
            $userId = ADMIN_ID;
        }

        /*
        $IndexCardBoxes = $this->IndexCardBox->find('list', array(
            'fields' => array('IndexCardBox.name'),
            'conditions' => array('IndexCardBox.user_id' => $userId),
            'order' => 'IndexCardBox.name ASC'
        ));

        $this->set('IndexCardBoxes', $IndexCardBoxes);
        */
    }

    function getdataset()
    {
        $this->autoRender = false; // disable error "missing view" because of ajax request

        if (!is_numeric($this->request->query['box']))
            throw new InvalidArgumentException('Invalid box id.');

        // cache index card box id
        //$this->Cookie->write('ict.box', $this->request->query['box'], false); // cannot modify header information

        // load models to fetch training data
        $this->loadModel('IndexCard');
        $this->loadModel('IndexCardBox');

        // identify user
        if ($this->Auth->loggedIn()) {
            $userId = $this->Auth->user('id');
        } else {
            // get dummy-data from admin
            $userId = ADMIN_ID;
        }

        /*
         * check, if  training Data for user exist and fetch it
         */

        $conditions = array('IndexCardBox.user_id' => $userId, 'IndexCardBox.id' => $this->request->query['box']);

        // add condition, if 'known' is set (checkbox is disabled)
        if (isset($this->request->query['known']) && $this->request->query['known'] == 'false') {
            // if isset, get all where known is null (not trained yet) or 0 (not known last time).            
            $conditions['OR'] = array(
                array('IndexCard.known < ' => 3)
            );
        }

        // add sort if set. Random will be handled by javascript
        // 0 = random, 1 = newest first (default), 2 = oldest first
        $sort = 'desc'; // newest first (default)

        if (isset($this->request->query['order']) && $this->request->query['order'] == 'ascending') {
            $sort = 'asc';

            // save in cookie
            $this->Cookie->write('ict.order', $this->request->query['order'], false);
        }

        $result = $this->IndexCard->find('all', array(
            'fields' => array('IndexCard.*'),
            'conditions' => $conditions,
            'order' => 'IndexCard.created ' . $sort
        ));

        // use cakeresponse prevent exceptions occured using cookies and ajax requests: headers already sent
        return new CakeResponse(array('body' => json_encode($result)));
    }
}

?>
