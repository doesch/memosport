<?php

class ContactController extends AppController
{
	
	function index()
	{		
        $this->set('title_for_layout', 'Kontakt');

        if($this->request->is('post'))
        {
            $this->Contact->set($this->data); /* necessary for validating data */

            if($this->Contact->validates())
            {
                $text = 'Name: '.$this->data['Contact']['name'].' | ';
                $text .= 'E-Mail: '.$this->data['Contact']['email'].' | ';
                $text .= $this->data['Contact']['text'];


                if(Mail::send('info@simon-doetsch.de', 'Kontaktformular nerdsports.de', $text))
                {
                    $this->Session->setFlash('Die Nachricht wurde erfolgreich versendet.');
                }
                else
                {
                    $this->Session->setFlash('Beim Versenden der Nachricht ist ein Fehler aufgetreten. Bitte senden Sie eine Nachricht direkt an info@memosport.de');
                }
            }
            else
            {
                //$this->Contact->invalidFields();
                //$this->Contact->validationErrors; /* doesn´t work automagic */

            }
        }
	}
	
}

?>