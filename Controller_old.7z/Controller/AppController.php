<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */

App::uses('Controller', 'Controller');

/**
 * Custom configs
 */

define('ADMIN_ID', 1); // Admin ID for dummy data
define('SIMON_ID', 66); // Admin ID for dummy data
define('BLANK_IMG', "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs%3D"); // blank image for image tags
define('NO_IMG', "//:0"); // blank image for image tags

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{

	/*
	 * Authentication for /admin
	 */

	public $components = array(
			'RequestHandler',
                        'Cookie',
			'Session',
			'Auth' => array(
					'loginAction' => array(
						// (Auth Mask) if access is restricted, the user will be forwarded to that Auth Mask 
						'controller' => 'User', 'action' => 'login'
					), 'loginRedirect' => array(
						// forwarded to this site, after loggin in
						'controller' => 'IndexCardTrainer', 'action' => 'index'
					), 'logoutRedirect' => array(
						'controller' => 'User', 'action' => 'login'
					),
					'authenticate' => array(
							'Form' => array(
								'fields' => array(
									'username' => 'email', 'password' => 'password'
								), 'userModel' => 'User'
							)
					), 'authorize' => array(
						'Controller'
					) // Used by ActionsAuthorize to locate controller action ACOs in the ACO tree
			)
	);

	public function beforeFilter()
	{
		/*
		 * Authentication (/user)
		 */
		
		$this->Auth->Allow('*');
		$this->Auth->authError = __('&nbsp;'); // no message on auth failure (e.g. /Admin)
		
		/*
		 * Mobile filter
		 */

		if ($this->RequestHandler->isMobile())
		{
		    // take flag to all views
		    $this->set('isMobile', true);
		}
		
		/*
		 * send user to view if logged in
		 */
		
		if($this->Auth->user())
		{
			$this->set('authUser', $this->Auth->user());
		}
                
		// set global cookie prefix (e.g. memosport[ict][box])
		$this->Cookie->name = 'memosport';
	}

	/**
	 * BAseclass helper for all controller that decides if the user is authorized or not
	 * @param $user
	 * @return bool
	 */
	public function isAuthorizedBase($user)
	{
		// Admin is able to access every action
		if (isset($user['role']) && ($user['role'] === 'admin' || $user['role'] === 'regular')) {
			return true;
		}
		// Default deny
		return false;
	}

	/*
	 * go to startpage if 404 (controller/action not found)
	 */

	public function appError($error)
	{
		$this->redirect('/');
	}
}
