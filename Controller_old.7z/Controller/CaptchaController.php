<?php 

class CaptchaController extends AppController
{
	function index()
	{
		// Grafik-Header (image/png) an den Browser senden
       //header ('Content-type: image/png');
	
       // Grafik erstellen
       $img = imageCreateTruecolor(150, 60);

        // Farbe für den Hintergrund erstellen
       $fuellfarbe = imageColorAllocate($img, 255, 255, 255);
       imageFill($img, 0, 0, $fuellfarbe);

       // alle Zeichen
       $captureArray = array(
       "a","b","c","d","e","f","g","h","i","j","k","l","n","p","q","r","s","t","u","v","x","y","z",
       0,1,2,3,4,5,6,7,8,9);

       // 4 Zeichen auswählen und direkt zeichnen
       $fontColor = imageColorAllocate($img, 193,205,205);

       imagettftext ( $img, 30, 0, 25, rand(30,50), $fontColor, $_SERVER['DOCUMENT_ROOT']."/app/verdana.ttf", $letter1 = $captureArray[rand(0,32)]);
       imagettftext ( $img, 30, 0, 45, rand(30,50), $fontColor, $_SERVER['DOCUMENT_ROOT']."/app/verdana.ttf", $letter2 = $captureArray[rand(0,32)]);
       imagettftext ( $img, 30, 0, 65, rand(30,50), $fontColor, $_SERVER['DOCUMENT_ROOT']."/app/verdana.ttf", $letter3 = $captureArray[rand(0,32)]);
       imagettftext ( $img, 30, 0, 85, rand(30,50), $fontColor, $_SERVER['DOCUMENT_ROOT']."/app/verdana.ttf", $letter4 = $captureArray[rand(0,32)]);
       imagettftext ( $img, 30, 0, 105, rand(30,50), $fontColor, $_SERVER['DOCUMENT_ROOT']."/app/verdana.ttf", $letter5 = $captureArray[rand(0,32)]);

       // Zeichen in Funktion zurück geben
       $captchaLetters = $letter1.$letter2.$letter3.$letter4.$letter5;
		
       //Session f�r sp�tere verifizierung in Session speichern
       $this->Session->write('Captcha.letters', $captchaLetters);
       
       // Vertikale Linien zeichen
       $linienFarbe = imageColorAllocate($img,193,205,205); // Farbe

       for($i = 1; $i < (150 / 10); $i++)
       {
           imageline( $img, (10 * $i), 0, (10 * $i), 60, $linienFarbe ); //Linie zeichnen
       }

       // horizontale Linien zeichen

       for($i = 1; $i < (60 / 10); $i++)
       {
           imageline( $img, 0, (10 * $i), 150, (10 * $i),  $linienFarbe ); //Linie zeichnen
       }

       // diagonale Linien zeichen

       imageline( $img, rand(10,30), 60,     rand(80,100), 0,  $linienFarbe ); //Linie zeichnen
       imageline( $img, rand(70,80), 60,     rand(50,60), 0,  $linienFarbe ); //Linie zeichnen
       imageline( $img, 0, rand(20,30),     150, rand(20,30),  $linienFarbe ); //Linie zeichnen


       // bild auffangen und in base64 codieren
       ob_start();
       imagepng($img);
       $stringdata = ob_get_contents();
       ob_end_clean(); // delete buffer
       $captchaImg = base64_encode($stringdata);

      $captchaImg = '{"arr":'.json_encode( Array( 'status' => true,
                                    'captchaImg' => $captchaImg )).'}';
       
       // muss �ber die View geechot werden.
       $this->set('captchaImg', $captchaImg);
	}
}

?>