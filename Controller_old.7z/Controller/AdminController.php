<?php

class AdminController extends AppController
{
	
	public function beforeFilter()
	{
	    $this->Auth->allow(); // allow nothing
	    $this->Auth->deny('create', 'delete', 'update', 'edit', 'index');
	    parent::beforeFilter();
	}
	
	/*
	 * Autorisierung
	 */

	public function isAuthorized($user)
	{
		// Admin can access every action
		if (isset($user['role']) && $user['role'] === 'admin')
		{
			return true;
		}
		// Default deny
		return false;
	}
	
	public function index()
	{
		//Load Model from different Controller
		$this->loadModel('Category');
		$this->loadModel('Technique');
		$this->loadModel('Article');
		
		// fetch all Categories
		$this->set('categories_arr', $this->Category->find('all'));
		
		//crate a list from Techniques			
		$this->set('categories', $this->Category->find('list'));
		
		//fetch all Techniques for deleting process
		$this->set('technique_arr', $this->Technique->find('all'));
		
		//fetch all Techniques for list
		$this->set('techniques', $this->Technique->find('list'));
	
		//fetch all Articles for edit modus
		$this->set('acticles_arr', $this->Article->find('all'));
	}
}
?>