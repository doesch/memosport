<?php

class IndexCardController extends AppController
{
    public $components = array('Cookie'); // load component to use cookies
    public $helpers = array('Js'); // javascript ajax

    public function beforeFilter()
    {
        $this->Auth->allow(); // allow nothing
        $this->Auth->deny("getlist", "add", "delete", "setknown");
        parent::beforeFilter();
		$this->set('submenu', 'ic');
    }

    /*
     * Autorisierung
     */

    public function isAuthorized($user)
    {
        return parent::isAuthorizedBase($user);
    }

    function index()
    {
        $this->autoRender = false;
    }

    function getlist()
    {
        $pBoxId = $this->request->query['pBoxId'];
        $pSearchstring = $this->request->query['pSearchstring'];

        $this->autoRender = false; // disable error "missing view" because of ajax request

        $this->loadModel('IndexCardBox');

        $userID = $this->Auth->user('id'); // get userid
        // get IndexCardBoxes for count and dropdown

        // add user id as condition
        $lConditions = Array(array('IndexCardBox.user_id' => $userID));

        // if searchstring has been typed, add it as condition
        if (isset($pSearchstring) && $pSearchstring !== "") // search
        {
            $lConditions['OR'] = array(
                'IndexCard.question LIKE' => '%' . $pSearchstring . '%',
                'IndexCard.jingle LIKE' => '%' . $pSearchstring . '%',
                'IndexCard.answer LIKE' => '%' . $pSearchstring . '%',
                'IndexCard.source LIKE' => '%' . $pSearchstring . '%');
        }

        if (is_numeric($pBoxId) && $pBoxId!= 0) {
            $lConditions['IndexCardBox.id'] = $pBoxId;
        }

        // get all index cards
        $IndexCards = $this->IndexCard->find('all', array(
            'conditions' => $lConditions,
            'order' => array('IndexCard.created DESC')
        ));

        echo json_encode($IndexCards);
    }

    function add()
    {
        $this->autoRender = false;

        if ($this->request->is('post')) // save new
        {
            $this->IndexCard->set($this->data); /* necessary for validating data */

            if ($this->IndexCard->validates())
            {
                if ($this->IndexCard->save($this->data))
                {
                    // return the iserted/updated row to the view
                    // at first, geht the id
                    $lId = null;

                    if(array_key_exists("id", $this->data["IndexCard"]))
                    {
                        // its an update
                        $lId = $this->data["IndexCard"]["id"];

                    }
                    else
                    {
                        // its a new post
                        $lId = $this->IndexCard->getLastInsertID();
                    }

                    // now query the last inserted/updated post
                    $this->IndexCard->recursive = -1; // do not get the box relation
                    echo json_encode($this->IndexCard->find('first', array('conditions' => array('IndexCard.id' => $lId))));
                }
            }
        }
    }

    function delete()
    {
        $this->autoRender = false;

        // do only allow post
        if($this->request->is('post'))
        {
            $id = $this->request->data['pId'];

            if (is_numeric($id)) {
                // check, if deleted row belongs to user
                $userID = $this->Auth->user('id'); // get userid

                $result = $this->IndexCard->find('first', array(
                    'conditions' => array('IndexCard.id' => $id, 'IndexCardBox.user_id' => $userID)
                ));

                if (count($result) > 0)
                {
                    if ($this->request->is('post') || $this->request->is('put'))
                    {
                        if ($this->IndexCard->delete($id))
                        {
                            echo json_encode(true);
                        }
                        else
                        {
                            $this->set('id', $id);
                        }
                    } else // get
                    {
                        // show index card
                        $this->set('item', $result);
                    }
                } else {
                    throw new Exception('This index card does not belong to the authenticated user.');
                }
            }
        }
    }

    function setknown()
    {
        $this->autoRender = false; // disable error "missing view" because of ajax request

        // get request data
        $id = $this->request->data['id'];
        $known = $this->request->data['known'];

        $this->loadModel('IndexCardBox');

        if (is_numeric($id) && is_numeric($known))
        {
            if ($this->request->is('post') || $this->request->is('put'))
            {
                $userID = $this->Auth->user('id'); // get userid

                $item = $this->IndexCard->find('first', array(
                    'conditions' => array('IndexCard.id' => $id, 'IndexCardBox.user_id' => $userID)
                ));

                if (!$item)
                {
                    throw new NotFoundException(__('Invalid index card'));
                }
                else
                {
                    // update value of field
                    $this->IndexCard->create();
                    $this->IndexCard->id = $id;
                    $this->IndexCard->saveField('known', $known);
                }
            }
            else
            {
                throw new HttpInvalidParamException(__('Invalid html verb'));
            }
        }
        else
        {
            throw new InvalidArgumentException(__('Invalid value'));
        }
    }
}

?>