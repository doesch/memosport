<?php

class IndexCardBoxController extends AppController
{
    public $components = array('Cookie'); // load component to use cookies

    public function beforeFilter()
    {
        $this->Auth->allow(); // allow nothing
        $this->Auth->deny(array('edit', 'index', 'add', 'delete'));
        parent::beforeFilter();
		$this->set('submenu', 'ic');
    }

    /*
     * Autorisierung
     */

    public function isAuthorized($user)
    {
        return parent::isAuthorizedBase($user);
    }

    function index()
    {
        $userID = $this->Auth->user('id'); // get userid


        $IndexCardBoxes = $this->IndexCardBox->find('all', array(
            'conditions' => array('IndexCardBox.user_id' => $userID),
            'order' => array('IndexCardBox.name ASC'),
        ));

        $this->set('IndexCardBoxes', $IndexCardBoxes);
    }

    function add()
    {
        if ($this->request->is('post'))
        {
            $this->IndexCardBox->set($this->data); /* necessary for validating data */

            if ($this->IndexCardBox->validates())
            {
                if ($this->IndexCardBox->save($this->data))
                {
                    $this->Session->setFlash(__('Der Karteikasten wurde angelegt. Legen Sie nun eine Karteikarte an.'));

                    /*
                     * save new in cookie and select in IndexCardBox
                     */

                    $this->Cookie->write('ict.box', $this->IndexCardBox->id, false); // 1 Week

                    return $this->redirect(array('controller' => 'IndexCardTrainer', 'action' => 'index'));
                }
                else
                {
                    $this->Session->setFlash(__('Karteikasten konnte nicht angelegt werden.'));
                }
            }
        }
    }

    function edit($id = null)
    {
        $userID = $this->Auth->user('id'); // get userid

        if (!$id) {
            throw new NotFoundException(__('Invalid id'));
        }

        $item = $this->IndexCardBox->find('first', array(
            'conditions' => array('IndexCardBox.id' => $id, 'IndexCardBox.user_id' => $userID)
        ));

        if (!$item) {
            throw new NotFoundException(__('Invalid index cardbox'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->IndexCardBox->id = $id;

            if ($this->IndexCardBox->validates()) {
                if ($this->IndexCardBox->save($this->request->data)) {
                    $this->Session->setFlash(__('Der Karteikasten wurde gespeichert.'));
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__('Der Karteikasten konnte nicht gespeichert werden.'));
                }
            }
        }

        // preallocate data
        if (!$this->request->data) {
            $this->request->data = $item;
        }

        $this->set('cDailyReminder', IndexCardBox::$cDailyReminder);
        $this->set('id', $id);
    }

    function delete($id)
    {
        if (is_numeric($id)) 
		{
            if ($this->request->is('post') || $this->request->is('put')) 
			{
				$userID = $this->Auth->user('id'); // get userid

				if (!$id) 
				{
					throw new NotFoundException(__('Invalid id'));
				}

				$item = $this->IndexCardBox->find('first', array(
					'conditions' => array('IndexCardBox.id' => $id, 'IndexCardBox.user_id' => $userID)
				));

				if (!$item) 
				{
					throw new NotFoundException(__('Invalid index cardbox'));
					$this->Session->setFlash(__('Karteikasten konnte nicht geloescht werden.'));
					$this->set('id', $id);
					return $this->redirect(array('action' => 'index'));
				}

				// delete box
                if ($this->IndexCardBox->delete($id)) 
				{
                    $this->Session->setFlash(__('Karteikasten geloescht.'));
                }
				else 
				{
                    $this->Session->setFlash(__('Karteikasten konnte nicht geloescht werden.'));
                    $this->set('id', $id);
                }

                return $this->redirect(array('action' => 'index'));
            } 
			else // get
            {
                $this->set('id', $id);
            }
        }
    }

    /**
     * Get index cards of logged in user
     * @return string
     */
    function GetAll()
    {
        // json
        $this->autoRender = false;

        // get userid
        $userID = $this->Auth->user('id');

        // do not get the related index cards. Only get the boxes
        $this->IndexCardBox->recursive = -1;

        // get all boxes of the user
        $IndexCardBoxes = $this->IndexCardBox->find('all', array(
            'conditions' => array('IndexCardBox.user_id' => $userID),
            'order' => array('IndexCardBox.name ASC'),
        ));

        return json_encode($IndexCardBoxes);
    }

	// Learn all index cards again
	function ResetState()
	{
		// json
        $this->autoRender = false;

        if ($this->request->is('post') || $this->request->is('put')) 
		{
			$userID = $this->Auth->user('id'); // get userid
			$id = $this->data["pBoxId"];

			if (!$id)
			{
				throw new NotFoundException(__('Invalid id'));
			}

			$item = $this->IndexCardBox->find('first', array(
				'conditions' => array('IndexCardBox.id' => $id, 'IndexCardBox.user_id' => $userID)
			));

			if (!$item) 
			{
				throw new NotFoundException(__('Invalid index cardbox'));
				$this->Session->setFlash(__('Die Box konnte dem nicht dem Nutzer zugeordnet werden.'));
			}
			else
			{
				// reset state
				$this->IndexCardBox->ResetState($id);
				return true;
			}
		}

		return false;
	}
}

?>