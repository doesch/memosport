<?php

App::uses('Component', 'Controller');
class ImageHandlerComponent extends Component 
{
    private $m_maxWidth = 640; // IPhone 4. Height is indifferent - scroll down
    private $m_path = "webroot/uploads/";
    
    
    // resizes and saves image to m_path
    // $file = file via post
    // $filename = new filename of file (use unique filename)
    public function save($file, $filename)
    {
        // check params
        if(empty($file['name']) || empty($file['tmp_name']) || empty($filename))
            throw new InvalidArgumentException('Invalid image file or filename');
        
        // generate location string
        $location = APP . $this->m_path . $filename;
        
        //get actual size
        $arr_size = getimagesize($file['tmp_name']);

        $width = $arr_size[0];
        $height = $arr_size[1];

        // check if bigger than allowed
        if ($width > $this->m_maxWidth)
        {
            $newWidth = $this->m_maxWidth;
            $newHeight = $this->m_maxWidth / $width * $height;
        }
        else
        {
            $newHeight = $height;
            $newWidth = $width;
        }
        
        // switch between file type
        switch (strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)))
        {
            case 'jpg' :
            case 'jpeg' : 
                    $src_image = imagecreatefromjpeg($file['tmp_name']);
                    $dst_image = imagecreatetruecolor($newWidth, $newHeight);

                    imagecopyresampled($dst_image, $src_image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    return imagejpeg($dst_image, $location, 100);	
            break;
            case 'png' : 
                    $src_image = imagecreatefrompng($file['tmp_name']);
                    $dst_image = imagecreatetruecolor($newWidth, $newHeight);

                    imagecopyresampled($dst_image, $src_image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    return imagepng($dst_image, $location, 0);	
            break;
            case 'gif' : 
                    $src_image = imagecreatefromgif($file['tmp_name']);
                    $dst_image = imagecreatetruecolor($newWidth, $newHeight);

                    imagecopyresampled($dst_image, $src_image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    return imagegif($dst_image, $location, 100);	
            break;
            default: return false;
        }
        
        return true;
    }
    
    // removes image from filesystem
    public function delete($filename)
    {
        if(empty($filename) || $filename == null)
            throw new InvalidArgumentException(__("argument 'filename' is null or empty.")); 
        
        // if file doesn´t exist, do not delete
        if(file_exists(APP . $this->m_path . $filename))
        {
            // change permission
            chmod(APP . $this->m_path . $filename, 777);

            // delete old image from filesystem
            if (!unlink(APP . $this->m_path . $filename))
            {
                throw new Exception(__('IndexCard.php: image '. $this->m_path . $filename . ' could not be deleted.'));            
            }
            else
            {
                return true;
            }
        }
        
        // do not throw exception, do only log error
        $this->log('Image delete fails: Image '. $this->m_path . $filename . ' could not be found.');
        
        return false;  
    }
}

?>