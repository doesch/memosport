<?php 

	Class ImprintController extends AppController
	{
            var $uses = false;
            
            function index()
            {
                $this->set('title_for_layout', 'Impressum');
            }	
	}
	
?>