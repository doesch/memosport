<?php

class UserController extends AppController
{
    public function beforeFilter()
    {
        parent::beforeFilter(); // inherit parent function and don�t overwrite
        $this->Auth->deny('delete', 'update', 'edit', 'index');
        $this->Auth->allow('create', 'login', 'sendnewpassword');
        $this->Auth->authError = ' '; // no auth error message
    }

    /*
     * Autorisierung
     */
    public function isAuthorized($user)
    {
        return parent::isAuthorizedBase($user);
    }

    public function index()
    {
        $this->set('userdata', $this->Auth->user('username'));
    }

    public function login()
    {
        // show only login form, if not logged in
        if ($this->Auth->user()) {
            $this->redirect('index');
        } else {
            if ($this->request->is('post')) {
                if ($this->Auth->login()) {

                    // if there is passed an url (e.g. ?redirect=/Controller/Action)
                    // redirect to the url after login,
                    // else use the default redirect
                    if(isset($this->request->query['redirect']))
                    {
                        $this->redirect($this->request->query['redirect']);
                    }
                    else
                    {
                        $this->redirect($this->Auth->redirect());
                    }
                } else {
                    $this->Session->setFlash(__('Falsche E-Mail Adresse oder Passwort! Bitte versuchen Sie es erneut. <br/><a href="/User/sendnewpassword">Passwort vergessen?</a>'), 'flash_error');
                }
            }
        }
    }

    public function logout()
    {
        $this->redirect($this->Auth->logout());
    }

    function create()
    {
        if ($this->request->is('post')) {
            // secure: rewrite user rule to prevent admin rights via maipulated post
            $this->request->data['User']['role'] = 'regular';

            if ($this->User->save($this->request->data)) {
                Mail::send('info@simon-doetsch.de', 'Neuer Nutzer registriert.', 'Auf memosport.de hat sich der Nutzer ' . $this->request->data['User']['username'] . ' registriert.');

                // login user
                //$this->Auth->login($this->User);

                $this->Session->setFlash(__('Das Benutzerkonto wurde erfolgreich angelegt.'));

                // go to login page
                $this->redirect(array('controller' => 'User', 'action' => 'index'));
            } else {
                $this->Session->setFlash(_('Das Benutzerkonto konnte nicht angelegt werden. Bitte versuche es erneut.'), 'flash_error');
            }
        }
    }

    function edit()
    {
        if ($this->Auth->user('id')) {
            $this->User->id = $this->Auth->user('id');

            // preallocation
            $item = $this->User->find('first', array(
                'conditions' => array('User.id' => $this->Auth->user('id'))
            ));

            if ($this->request->is('post') || $this->request->is('put')) {
                if ($this->User->validates()) {
                    if ($this->User->save($this->request->data)) {
                        $this->Session->setFlash(_('Das Password wurde geändert.'));
                        $this->redirect(array('action' => 'index'));
                    } else {
                        $this->Session->setFlash(_('Das Passwort konnte nicht geändert werden.'), 'flash_error');
                    }
                }
            }

            // preallocate data
            if (!$this->request->data) {
                $this->request->data = $item;
            }
        } else {
            $this->redirect(array('controller' => 'user', 'action' => 'login'));
        }
    }

    function delete()
    {
        // first, get confirmation
        if ($this->request->is('post')) {
            if ($this->request->data['User']['confirm'] = 'confirm') {
                if ($this->User->delete($this->Auth->user('id'))) {
                    $this->Session->setFlash('Das Benutzerkonto wurde gelöscht!');
                    $this->Auth->logout();
                    $this->redirect('/');
                } else {
                    $this->Session->setFlash(_('Das Benutzerkonto konnte nicht gelöscht werden. Bitte kontaktieren Sie den Support.'), 'flash_error');
                }
            }
        }
    }

    function sendnewpassword()
    {
        if ($this->request->is('post')) {
            //check e-mail
            $user = $this->User->findByEmail($this->data['User']['email']);

            if (!empty($user)) {
                // generate new password
                $str_new_pw = '';
                $pool = 'qwertzupasdfghkyxcvbnm23456789';
                srand((double)microtime() * 1000000);

                for ($n = 0; $n <= 6; $n++) {
                    $str_new_pw .= substr($pool, (rand() % (strlen($pool))), 1);
                }

                // update password
                $data = array('id' => $user['User']['id'], 'password' => $str_new_pw);

                // mailtext
                $mailtext = "Ihr neues Passwort lautet: " . $str_new_pw . ". Sie können sich mit dem neuen Passwort auf http://www.nerdsports.de/User einloggen.";

                if ($this->User->save($data) && Mail::send($this->data['User']['email'], "Ihr neues Passwort auf memosport.de", $mailtext)) {
                    $this->Session->setFlash('Das neue Password wurde an die angegebene Adresse versendet.');
                    $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(_('Beim Setzen des Passwortes ist ein Fehler aufgetreten. Bitte kontaktieren Sie den <a href="/contact">Support</a>.'), 'flash_error');
                }
            } else {
                $this->Session->setFlash(('Es konnte kein Nutzer mit dieser E-Mail Adresse gefunden werden.'), 'flash_error');
            }
        }
    }

}

?>